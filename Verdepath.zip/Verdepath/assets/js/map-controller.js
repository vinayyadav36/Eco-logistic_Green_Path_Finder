/* ============================================
   VerdePath — Map Controller
   Leaflet.js map init, route drawing, markers
   ============================================ */

(function initMapController() {
  'use strict';

  let map = null;
  let routeLayers = [];
  let markerLayers = [];
  let trafficLayers = [];

  // CartoDB Dark Matter tiles
  const TILE_URL = 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png';
  const TILE_ATTR = '&copy; <a href="https://www.openstreetmap.org/copyright">OSM</a> &copy; <a href="https://carto.com/">CARTO</a>';

  // Default center: Haryana, India
  const DEFAULT_CENTER = [29.0588, 76.0856];
  const DEFAULT_ZOOM = 8;

  /**
   * Initialize the Leaflet map on a given container element ID
   */
  function initMap(containerId = 'map') {
    if (typeof L === 'undefined') {
      console.error('Leaflet.js is not loaded.');
      return null;
    }
    if (map) return map; // Already initialized

    map = L.map(containerId, {
      center: DEFAULT_CENTER,
      zoom: DEFAULT_ZOOM,
      zoomControl: true,
      attributionControl: true
    });

    L.tileLayer(TILE_URL, {
      attribution: TILE_ATTR,
      maxZoom: 19,
      subdomains: 'abcd'
    }).addTo(map);

    // Add locate button
    addLocateButton();

    return map;
  }

  /**
   * Add a "Locate Me" button to the map
   */
  function addLocateButton() {
    if (!map) return;

    const LocateControl = L.Control.extend({
      options: { position: 'topright' },
      onAdd: function () {
        const btn = L.DomUtil.create('button', 'leaflet-bar leaflet-locate-btn');
        btn.innerHTML = '📍';
        btn.title = 'Locate Me';
        btn.style.cssText = 'width:36px;height:36px;font-size:18px;cursor:pointer;background:var(--bg-secondary,#0a1628);border:1px solid rgba(0,255,136,0.3);border-radius:6px;display:flex;align-items:center;justify-content:center;';
        L.DomEvent.disableClickPropagation(btn);
        btn.addEventListener('click', () => {
          map.locate({ setView: true, maxZoom: 14 });
        });
        return btn;
      }
    });

    new LocateControl().addTo(map);
  }

  /**
   * Create a custom div icon (circle marker)
   */
  function createCircleIcon(color, size = 16) {
    return L.divIcon({
      className: 'vp-marker',
      html: `<div style="
        width:${size}px;height:${size}px;
        background:${color};
        border:3px solid #fff;
        border-radius:50%;
        box-shadow:0 0 12px ${color}88;
      "></div>`,
      iconSize: [size, size],
      iconAnchor: [size / 2, size / 2]
    });
  }

  /**
   * Place origin and destination markers
   */
  function setMarkers(originLatLng, destLatLng, originLabel, destLabel) {
    clearMarkers();

    if (originLatLng) {
      const m = L.marker(originLatLng, {
        icon: createCircleIcon('#00ff88', 18)
      }).addTo(map);
      if (originLabel) m.bindTooltip(originLabel, { permanent: false, direction: 'top' });
      markerLayers.push(m);
    }

    if (destLatLng) {
      const m = L.marker(destLatLng, {
        icon: createCircleIcon('#f43f5e', 18)
      }).addTo(map);
      if (destLabel) m.bindTooltip(destLabel, { permanent: false, direction: 'top' });
      markerLayers.push(m);
    }
  }

  /**
   * Draw up to 3 routes on the map
   * Each route: { geometry: GeoJSON, label, color, weight, dashArray? }
   */
  function drawRoutes(routes) {
    clearRoutes();

    const routeStyles = [
      { color: '#00ff88', weight: 5, opacity: 0.9 },   // Route A — greenest
      { color: '#fbbf24', weight: 4, opacity: 0.8 },   // Route B — moderate
      { color: '#f43f5e', weight: 3, opacity: 0.7, dashArray: '8 6' }  // Route C — high emission
    ];

    routes.forEach((route, i) => {
      const style = routeStyles[i] || routeStyles[2];
      let layer;

      if (route.geometry && route.geometry.type === 'LineString') {
        // GeoJSON LineString: coordinates are [lng, lat]
        const latlngs = route.geometry.coordinates.map(c => [c[1], c[0]]);
        layer = L.polyline(latlngs, {
          color: route.color || style.color,
          weight: style.weight,
          opacity: style.opacity,
          dashArray: style.dashArray || null,
          lineCap: 'round',
          lineJoin: 'round'
        }).addTo(map);
      } else {
        return; // Skip if no geometry
      }

      // Tooltip on hover
      const label = route.label || `Route ${String.fromCharCode(65 + i)}`;
      const co2Text = route.co2_kg !== undefined ? ` · ${route.co2_kg} kg CO₂` : '';
      layer.bindTooltip(`${label}${co2Text}`, { sticky: true });

      routeLayers.push(layer);
    });

    // Fit bounds to show all routes
    fitBounds();
  }

  /**
   * Fit map bounds to show all route layers + markers
   */
  function fitBounds() {
    const group = L.featureGroup([...routeLayers, ...markerLayers]);
    if (group.getLayers().length > 0) {
      map.fitBounds(group.getBounds().pad(0.15));
    }
  }

  /**
   * Clear all route polylines
   */
  function clearRoutes() {
    routeLayers.forEach(l => map.removeLayer(l));
    routeLayers = [];
  }

  /**
   * Clear all markers
   */
  function clearMarkers() {
    markerLayers.forEach(l => map.removeLayer(l));
    markerLayers = [];
  }

  function clearTraffic() {
    trafficLayers.forEach(l => map.removeLayer(l));
    trafficLayers = [];
  }

  function simulateTraffic(routeGeometry, trafficLevel) {
    clearTraffic();
    if (!routeGeometry || !routeGeometry.coordinates || !map) return;
    
    // Choose density: low = 5, medium = 15, high = 30
    const count = trafficLevel === 'high' ? 30 : (trafficLevel === 'medium' ? 15 : 5);
    const coords = routeGeometry.coordinates; // [lng, lat]
    
    // Pick 'count' random points along the route
    for(let i = 0; i < count; i++) {
       const idx = Math.floor(Math.random() * coords.length);
       const pt = coords[idx];
       
       const carIcon = L.divIcon({
         className: 'traffic-car',
         html: '<div style="font-size:18px; line-height:1; filter: drop-shadow(0 2px 4px rgba(0,0,0,0.5));">🚗</div>',
         iconSize: [20, 20],
         iconAnchor: [10, 10],
         bgPos: [0, 0]
       });
       
       const marker = L.marker([pt[1], pt[0]], { icon: carIcon }).addTo(map);
       trafficLayers.push(marker);
    }
  }

  function selectRouteOnMap(index) {
    routeLayers.forEach((layer, i) => {
      if (i === index) {
        layer.setStyle({ opacity: 1, weight: 7 });
        layer.bringToFront();
      } else {
        layer.setStyle({ opacity: 0.3, weight: 3 });
      }
    });
  }

  /**
   * Clear everything
   */
  function clearAll() {
    clearRoutes();
    clearMarkers();
    clearTraffic();
  }

  /**
   * Get the map instance
   */
  function getMap() {
    return map;
  }

  // Expose globally
  window.VerdePath = window.VerdePath || {};
  Object.assign(window.VerdePath, {
    initMap,
    setMarkers,
    drawRoutes,
    selectRouteOnMap,
    simulateTraffic,
    clearRoutes,
    clearMarkers,
    clearTraffic,
    clearAll,
    fitBounds,
    getMap
  });

})();
