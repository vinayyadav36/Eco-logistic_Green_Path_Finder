/* ============================================
   VerdePath — Auth Modal
   Reusable glass modal with Sign In / Sign Up
   ============================================ */

(function initAuthModal() {
  'use strict';

  // ---- Build Modal DOM ----
  const overlay = document.createElement('div');
  overlay.id = 'auth-modal';
  overlay.className = 'auth-overlay';
  overlay.innerHTML = `
    <div class="auth-modal glass-card" style="background: linear-gradient(145deg, rgba(16, 28, 45, 0.9) 0%, rgba(10, 22, 40, 0.95) 100%); border: 1px solid rgba(0, 255, 136, 0.2); box-shadow: 0 0 40px rgba(0, 255, 136, 0.1);">
      <button class="auth-modal__close" id="authCloseBtn" aria-label="Close">&times;</button>

      <div style="text-align: center; margin-bottom: 24px;">
        <div style="font-size: 2.5rem; margin-bottom: 8px;">🌿</div>
        <h2 style="font-family: var(--font-heading); font-size: 1.5rem; margin: 0; color: var(--text-primary);">Welcome to VerdePath</h2>
        <p style="color: var(--text-secondary); font-size: 0.9rem; margin-top: 4px;">Log in to calculate your greenest routes.</p>
      </div>

      <!-- Tabs -->
      <div class="auth-tabs">
        <button class="auth-tab active" data-tab="signin">Sign In</button>
        <button class="auth-tab" data-tab="signup">Sign Up</button>
      </div>

      <button type="button" class="btn-secondary" id="googleAuthBtn" style="width:100%; justify-content:center; margin-bottom:12px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1);">
        <svg width="18" height="18" viewBox="0 0 48 48"><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/><path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/></svg>
        Continue with Google
      </button>
      <div style="text-align:center; color: var(--text-muted); font-size: 0.8rem; margin-bottom: 20px;">— or —</div>


      <!-- Sign In Form -->
      <form class="auth-form" id="signinForm">
        <div class="auth-field">
          <label for="signin-email">Email</label>
          <input type="email" id="signin-email" class="input-field" placeholder="you@company.com" required>
        </div>
        <div class="auth-field">
          <label for="signin-password">Password</label>
          <input type="password" id="signin-password" class="input-field" placeholder="••••••••" required minlength="6">
        </div>
        <button type="submit" class="btn-primary auth-submit" id="signinBtn">
          <span class="auth-submit__text">Sign In</span>
          <span class="auth-submit__spinner spinner spinner--sm" style="display:none;"></span>
        </button>
        <a href="#" class="auth-forgot">Forgot password?</a>
        <div class="auth-error" id="signinError"></div>
      </form>

      <!-- Sign Up Form -->
      <form class="auth-form" id="signupForm" style="display:none;">
        <div class="auth-field">
          <label for="signup-name">Full Name</label>
          <input type="text" id="signup-name" class="input-field" placeholder="Alex Green" required>
        </div>
        <div class="auth-field">
          <label for="signup-company">Company Name</label>
          <input type="text" id="signup-company" class="input-field" placeholder="GreenFleet Ltd.">
        </div>
        <div class="auth-field">
          <label for="signup-fleet">Fleet Size</label>
          <input type="number" id="signup-fleet" class="input-field" placeholder="10" min="1" value="1">
        </div>
        <div class="auth-field">
          <label for="signup-email">Email</label>
          <input type="email" id="signup-email" class="input-field" placeholder="you@company.com" required>
        </div>
        <div class="auth-field">
          <label for="signup-password">Password</label>
          <input type="password" id="signup-password" class="input-field" placeholder="Min 6 characters" required minlength="6">
        </div>
        <div class="auth-field">
          <label for="signup-confirm">Confirm Password</label>
          <input type="password" id="signup-confirm" class="input-field" placeholder="Re-enter password" required minlength="6">
        </div>
        <button type="submit" class="btn-primary auth-submit" id="signupBtn">
          <span class="auth-submit__text">Create Account</span>
          <span class="auth-submit__spinner spinner spinner--sm" style="display:none;"></span>
        </button>
        <div class="auth-error" id="signupError"></div>
      </form>
    </div>
  `;

  // Inject styles
  const style = document.createElement('style');
  style.textContent = `
    .auth-overlay {
      display: none;
      position: fixed;
      inset: 0;
      z-index: 9999;
      background: rgba(0, 0, 0, 0.7);
      backdrop-filter: blur(8px);
      -webkit-backdrop-filter: blur(8px);
      align-items: center;
      justify-content: center;
      animation: fadeIn 0.25s ease;
    }
    .auth-overlay.open { display: flex; }

    .auth-modal {
      position: relative;
      width: 100%;
      max-width: 420px;
      margin: 16px;
      padding: 36px 32px 28px;
      max-height: 90vh;
      overflow-y: auto;
    }

    .auth-modal__close {
      position: absolute;
      top: 14px;
      right: 18px;
      background: none;
      border: none;
      color: var(--text-muted);
      font-size: 1.6rem;
      cursor: pointer;
      transition: var(--transition);
      line-height: 1;
    }
    .auth-modal__close:hover { color: var(--text-primary); }

    .auth-tabs {
      display: flex;
      gap: 4px;
      margin-bottom: 28px;
      background: rgba(255,255,255,0.04);
      border-radius: 12px;
      padding: 4px;
    }
    .auth-tab {
      flex: 1;
      padding: 10px;
      border: none;
      border-radius: 10px;
      background: transparent;
      color: var(--text-secondary);
      font-family: 'DM Sans', sans-serif;
      font-weight: 500;
      font-size: 0.9rem;
      cursor: pointer;
      transition: var(--transition);
    }
    .auth-tab.active {
      background: rgba(0, 255, 136, 0.12);
      color: var(--accent-green);
    }

    .auth-form { display: flex; flex-direction: column; gap: 16px; }
    .auth-field { display: flex; flex-direction: column; gap: 6px; }
    .auth-field label {
      font-size: 0.82rem;
      color: var(--text-secondary);
      font-weight: 500;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }
    .auth-field input {
      padding: 12px 16px;
      border-radius: 8px;
      background: rgba(0,0,0,0.2) !important;
      border: 1px solid rgba(255,255,255,0.1) !important;
      transition: all 0.2s ease;
      color: var(--text-primary);
    }
    .auth-field input:focus {
      background: rgba(0,0,0,0.4) !important;
      border-color: var(--accent-green) !important;
      outline: none;
      box-shadow: 0 0 0 2px rgba(0,255,136,0.1);
    }

    .auth-submit {
      width: 100%;
      margin-top: 8px;
      padding: 12px;
      font-size: 1rem;
      border-radius: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
    }


    .auth-forgot {
      text-align: center;
      font-size: 0.82rem;
      color: var(--text-muted);
    }
    .auth-forgot:hover { color: var(--accent-green); }

    .auth-error {
      font-size: 0.85rem;
      color: var(--accent-red);
      text-align: center;
      min-height: 20px;
    }
  `;
  document.head.appendChild(style);
  document.body.appendChild(overlay);

  // ---- Tab Switching ----
  const tabs = overlay.querySelectorAll('.auth-tab');
  const signinForm = overlay.querySelector('#signinForm');
  const signupForm = overlay.querySelector('#signupForm');

  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      const isSignIn = tab.dataset.tab === 'signin';
      signinForm.style.display = isSignIn ? 'flex' : 'none';
      signupForm.style.display = isSignIn ? 'none' : 'flex';
      // Clear errors
      overlay.querySelector('#signinError').textContent = '';
      overlay.querySelector('#signupError').textContent = '';
    });
  });

  // ---- Open / Close ----
  function openModal(defaultTab) {
    overlay.classList.add('open');
    document.body.style.overflow = 'hidden';
    if (defaultTab === 'signup') {
      tabs[1].click();
    } else {
      tabs[0].click();
    }
  }

  function closeModal() {
    overlay.classList.remove('open');
    document.body.style.overflow = '';
  }

  overlay.querySelector('#authCloseBtn').addEventListener('click', closeModal);
  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) closeModal();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeModal();
  });

  // ---- Trigger Elements ----
  document.addEventListener('click', (e) => {
    if (e.target.closest('.trigger-auth')) {
      e.preventDefault();
      openModal('signin');
    }
  });

  // Check for #auth-modal hash
  if (window.location.hash === '#auth-modal') {
    openModal('signin');
  }

  // ---- Loading State Helper ----
  function setLoading(btn, loading) {
    const text = btn.querySelector('.auth-submit__text');
    const spin = btn.querySelector('.auth-submit__spinner');
    if (loading) {
      text.style.display = 'none';
      spin.style.display = 'inline-block';
      btn.disabled = true;
    } else {
      text.style.display = 'inline';
      spin.style.display = 'none';
      btn.disabled = false;
    }
  }

  // ---- Google Auth Hub ----
  overlay.querySelector('#googleAuthBtn').addEventListener('click', async () => {
    try {
      if (window.VerdePath && window.VerdePath.getSupabase) {
        const sb = window.VerdePath.getSupabase();
        await sb.auth.signInWithOAuth({
          provider: 'google',
          options: {
            redirectTo: window.location.origin + '/dashboard.html'
          }
        });
      }
    } catch (err) {
      console.error('Google Auth Error:', err);
    }
  });

  // ---- Sign In Submit ----
  signinForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const errorEl = overlay.querySelector('#signinError');
    errorEl.textContent = '';

    const email = overlay.querySelector('#signin-email').value.trim();
    const password = overlay.querySelector('#signin-password').value;
    const btn = overlay.querySelector('#signinBtn');

    if (!email || !password) {
      errorEl.textContent = 'Please fill in all fields.';
      return;
    }

    setLoading(btn, true);
    try {
      if (window.VerdePath && window.VerdePath.signIn) {
        await window.VerdePath.signIn(email, password);
      } else {
        throw new Error('Supabase client not loaded.');
      }
    } catch (err) {
      errorEl.textContent = err.message || 'Sign in failed. Please try again.';
    } finally {
      setLoading(btn, false);
    }
  });

  // ---- Sign Up Submit ----
  signupForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const errorEl = overlay.querySelector('#signupError');
    errorEl.textContent = '';

    const fullName = overlay.querySelector('#signup-name').value.trim();
    const company = overlay.querySelector('#signup-company').value.trim();
    const fleetSize = parseInt(overlay.querySelector('#signup-fleet').value, 10) || 1;
    const email = overlay.querySelector('#signup-email').value.trim();
    const password = overlay.querySelector('#signup-password').value;
    const confirm = overlay.querySelector('#signup-confirm').value;
    const btn = overlay.querySelector('#signupBtn');

    if (!fullName || !email || !password) {
      errorEl.textContent = 'Please fill in all required fields.';
      return;
    }
    if (password !== confirm) {
      errorEl.textContent = 'Passwords do not match.';
      return;
    }
    if (password.length < 6) {
      errorEl.textContent = 'Password must be at least 6 characters.';
      return;
    }

    setLoading(btn, true);
    try {
      if (window.VerdePath && window.VerdePath.signUp) {
        await window.VerdePath.signUp(email, password, fullName, company, fleetSize);
      } else {
        throw new Error('Supabase client not loaded.');
      }
    } catch (err) {
      errorEl.textContent = err.message || 'Sign up failed. Please try again.';
    } finally {
      setLoading(btn, false);
    }
  });

  // Make openModal globally available
  window.openAuthModal = openModal;

})();
