/* ============================================
   VerdePath — Emission Factors
   Vehicle CO₂ data + calculation functions
   (IPCC / MoEFCC India standard values)
   ============================================ */

// ---- Vehicle Emission Factors ----
const EMISSION_FACTORS = {
  bike:      { co2PerKm: 0,     fuelPerKm: 0,     label: 'Bicycle',       emoji: '🚲', fuelType: 'None' },
  motorbike: { co2PerKm: 0.103, fuelPerKm: 0.043, label: 'Motorbike',     emoji: '🏍️', fuelType: 'Petrol' },
  car:       { co2PerKm: 0.192, fuelPerKm: 0.08,  label: 'Car (Petrol)',  emoji: '🚗', fuelType: 'Petrol' },
  van:       { co2PerKm: 0.270, fuelPerKm: 0.108, label: 'Delivery Van',  emoji: '🚐', fuelType: 'Diesel' },
  truck:     { co2PerKm: 0.620, fuelPerKm: 0.248, label: 'Truck (HGV)',   emoji: '🚛', fuelType: 'Diesel' },
  ev_car:    { co2PerKm: 0.053, fuelPerKm: 0,     label: 'EV Car',        emoji: '⚡', fuelType: 'Electric' },
  ev_van:    { co2PerKm: 0.089, fuelPerKm: 0,     label: 'EV Van',        emoji: '⚡', fuelType: 'Electric' }
};

// ---- Traffic Multipliers ----
const TRAFFIC_MULTIPLIERS = {
  low:    1.0,
  medium: 1.3,
  high:   1.7
};

// ---- Time of Day Multipliers ----
const TIME_MULTIPLIERS = {
  morning_peak: 1.4,
  off_peak:     1.0,
  evening_peak: 1.5
};

// ---- Baseline Vehicle (used for savings calc) ----
const BASELINE_VEHICLE = 'van'; // Diesel van = worst common case

// ---- Carbon Credit Rate ----
const CARBON_CREDIT_RATE_INR = 500; // ₹500 per tonne (India CBAM estimate)

// ---- Core Calculation Functions ----

/**
 * Calculate emissions for a given route
 * @returns {{ co2_kg, fuel_liters, green_score }}
 */
function calculateEmissions(vehicleType, distanceKm, trafficLevel = 'medium', timeOfDay = 'off_peak') {
  const factor = EMISSION_FACTORS[vehicleType];
  if (!factor) throw new Error(`Unknown vehicle type: ${vehicleType}`);

  const trafficMult = TRAFFIC_MULTIPLIERS[trafficLevel] || 1.0;
  const timeMult = TIME_MULTIPLIERS[timeOfDay] || 1.0;

  const co2_kg = distanceKm * factor.co2PerKm * trafficMult * timeMult;
  const fuel_liters = distanceKm * factor.fuelPerKm * trafficMult;
  const green_score = co2_kg; // Lower = more eco-friendly

  return {
    co2_kg: Math.round(co2_kg * 100) / 100,
    fuel_liters: Math.round(fuel_liters * 100) / 100,
    green_score: Math.round(green_score * 100) / 100
  };
}

/**
 * Calculate savings vs diesel van baseline
 * @returns {{ saved_kg, saved_percent, credit_value_inr }}
 */
function calculateSavings(actualCO2, vehicleType, distanceKm) {
  const baseline = calculateEmissions(BASELINE_VEHICLE, distanceKm, 'medium', 'off_peak');
  const saved_kg = Math.max(0, baseline.co2_kg - actualCO2);
  const saved_percent = baseline.co2_kg > 0
    ? Math.round((saved_kg / baseline.co2_kg) * 100)
    : 0;
  const credit_value_inr = Math.round((saved_kg / 1000) * CARBON_CREDIT_RATE_INR * 100) / 100;

  return {
    saved_kg: Math.round(saved_kg * 100) / 100,
    saved_percent,
    credit_value_inr
  };
}

/**
 * How many trees would absorb this CO₂ in a day?
 * Average tree absorbs ~22 kg CO₂/year ≈ 0.06 kg/day
 */
function getTreeEquivalent(co2_kg) {
  const treeDailyAbsorption = 0.06; // kg CO₂ per tree per day
  return Math.round(co2_kg / treeDailyAbsorption);
}

/**
 * Convert CO₂ saved to carbon credit value in INR
 */
function getCreditValue(co2_kg) {
  return Math.round((co2_kg / 1000) * CARBON_CREDIT_RATE_INR * 100) / 100;
}

/**
 * Format duration in seconds to human-readable
 */
function formatDuration(seconds) {
  const hrs = Math.floor(seconds / 3600);
  const mins = Math.round((seconds % 3600) / 60);
  if (hrs > 0) return `${hrs}h ${mins}m`;
  return `${mins}m`;
}

/**
 * Format distance in km
 */
function formatDistance(km) {
  return km < 1 ? `${Math.round(km * 1000)} m` : `${km.toFixed(1)} km`;
}

// Make available globally
window.VerdePath = window.VerdePath || {};
Object.assign(window.VerdePath, {
  EMISSION_FACTORS,
  TRAFFIC_MULTIPLIERS,
  TIME_MULTIPLIERS,
  calculateEmissions,
  calculateSavings,
  getTreeEquivalent,
  getCreditValue,
  formatDuration,
  formatDistance
});
