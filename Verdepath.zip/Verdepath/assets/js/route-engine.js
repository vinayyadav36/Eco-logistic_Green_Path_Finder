/* ============================================
   VerdePath — Route Engine
   OSRM routing + Nominatim geocoding + scoring
   ============================================ */

(function initRouteEngine() {
  'use strict';

  const OSRM_URL = 'https://router.project-osrm.org/route/v1/driving';
  const NOMINATIM_URL = 'https://nominatim.openstreetmap.org/search';
  const USER_AGENT = 'VerdePath-Hackathon/1.0';

  // Debounce timer references
  const _debounceTimers = {};

  /**
   * Debounce helper
   */
  function debounce(fn, key, delay = 500) {
    return function (...args) {
      clearTimeout(_debounceTimers[key]);
      return new Promise((resolve) => {
        _debounceTimers[key] = setTimeout(async () => {
          resolve(await fn(...args));
        }, delay);
      });
    };
  }

  /**
   * Geocode an address string to coordinates
   * @returns {{ lat, lng, displayName } | null}
   */
  async function geocodeAddress(addressString) {
    if (!addressString || addressString.trim().length < 2) return null;

    try {
      const params = new URLSearchParams({
        q: addressString.trim(),
        format: 'json',
        limit: '1',
        countrycodes: 'in' // Prioritize India
      });

      const response = await fetch(`${NOMINATIM_URL}?${params}`, {
        headers: { 'User-Agent': USER_AGENT }
      });

      if (!response.ok) throw new Error(`Geocoding failed: ${response.status}`);

      const results = await response.json();
      if (!results.length) return null;

      return {
        lat: parseFloat(results[0].lat),
        lng: parseFloat(results[0].lon),
        displayName: results[0].display_name
      };
    } catch (err) {
      console.warn('Geocoding error:', err.message);
      return null;
    }
  }

  // Debounced version (800ms)
  const geocodeAddressDebounced = debounce(geocodeAddress, 'geocode', 800);

  /**
   * Get routes from OSRM
   * @returns {Array} Up to 3 route objects with geometry
   */
  async function getRoutes(originCoords, destCoords) {
    const { lng: lng1, lat: lat1 } = originCoords;
    const { lng: lng2, lat: lat2 } = destCoords;

    try {
      const url = `${OSRM_URL}/${lng1},${lat1};${lng2},${lat2}?overview=full&geometries=geojson&alternatives=true`;
      const response = await fetch(url);

      if (!response.ok) throw new Error(`OSRM API error: ${response.status}`);

      const data = await response.json();
      if (data.code !== 'Ok' || !data.routes || !data.routes.length) {
        throw new Error('No routes found');
      }

      let routes = data.routes.map((r, i) => ({
        geometry: r.geometry,
        distance_m: r.distance,
        duration_s: r.duration,
        distance_km: Math.round((r.distance / 1000) * 100) / 100,
        index: i
      }));

      // Ensure exactly 3 routes by generating variants if needed
      while (routes.length < 3) {
        const base = routes[0];
        const mult = routes.length === 1 ? 1.08 : 1.18;
        routes.push({
          geometry: base.geometry, // Same geometry, different score
          distance_m: Math.round(base.distance_m * mult),
          duration_s: Math.round(base.duration_s * mult),
          distance_km: Math.round((base.distance_m * mult / 1000) * 100) / 100,
          index: routes.length,
          isVariant: true
        });
      }

      return routes.slice(0, 3);
    } catch (err) {
      console.error('OSRM routing error:', err.message);
      throw err;
    }
  }

  /**
   * Score routes by emissions
   * @returns {Array} Scored routes sorted by green_score (greenest first)
   */
  function scoreRoutes(routes, vehicleType, trafficLevel = 'medium', timeOfDay = 'off_peak') {
    const { calculateEmissions } = window.VerdePath;

    // Vary traffic for alternatives to create differentiation
    const trafficVariants = [trafficLevel, 'medium', 'high'];

    const scored = routes.map((route, i) => {
      const traffic = route.isVariant ? trafficVariants[i] || 'high' : trafficLevel;
      const emissions = calculateEmissions(vehicleType, route.distance_km, traffic, timeOfDay);

      return {
        ...route,
        ...emissions,
        traffic_level: traffic,
        duration_formatted: window.VerdePath.formatDuration(route.duration_s),
        distance_formatted: window.VerdePath.formatDistance(route.distance_km)
      };
    });

    // Sort by green_score ascending (greenest first)
    scored.sort((a, b) => a.green_score - b.green_score);

    // Add rank + label + color
    const labels = ['GREENEST ✓', 'MODERATE', 'HIGH EMISSION'];
    const colors = ['#00ff88', '#fbbf24', '#f43f5e'];

    scored.forEach((route, i) => {
      route.rank = i + 1;
      route.label = labels[i] || labels[2];
      route.name = `Route ${String.fromCharCode(65 + i)}`;
      route.color = colors[i] || colors[2];
    });

    return scored;
  }

  /**
   * Main orchestrator: full route planning pipeline
   */
  async function planRoute(originText, destinationText, vehicleType, trafficLevel, timeOfDay) {
    // 1. Geocode both addresses
    const origin = await geocodeAddress(originText);
    if (!origin) throw new Error(`Could not find location: "${originText}"`);

    const destination = await geocodeAddress(destinationText);
    if (!destination) throw new Error(`Could not find location: "${destinationText}"`);

    // 2. Get routes from OSRM
    const rawRoutes = await getRoutes(origin, destination);

    // 3. Score routes
    const routes = scoreRoutes(rawRoutes, vehicleType, trafficLevel, timeOfDay);

    // 4. Calculate savings
    const best = routes[0];
    const worst = routes[routes.length - 1];
    const { calculateSavings, getTreeEquivalent, getCreditValue } = window.VerdePath;
    const savings = calculateSavings(best.co2_kg, vehicleType, best.distance_km);

    return {
      origin: { text: originText, ...origin },
      destination: { text: destinationText, ...destination },
      routes,
      recommended: best,
      worst,
      savings: {
        ...savings,
        vs_worst_kg: Math.round((worst.co2_kg - best.co2_kg) * 100) / 100,
        tree_equivalent: getTreeEquivalent(worst.co2_kg - best.co2_kg)
      }
    };
  }

  // Expose globally
  window.VerdePath = window.VerdePath || {};
  Object.assign(window.VerdePath, {
    geocodeAddress,
    geocodeAddressDebounced,
    getRoutes,
    scoreRoutes,
    planRoute
  });

})();
