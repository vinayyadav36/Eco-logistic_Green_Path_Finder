/* ============================================
   VerdePath — AI Advisor
   Connects to Supabase Edge Function running Claude
   ============================================ */

(function initAiAdvisor() {
  'use strict';

  // ⚠️ Replace with your actual deployed Edge Function URL
  const EDGE_FUNCTION_URL = 'https://iyjbopudpzdobpbiiiro.supabase.co/functions/v1/ai-advisor';

  /**
   * Generic POST to the AI Advisor edge function
   */
  async function callAdvisor(payload) {
    const sb = window.VerdePath && window.VerdePath.getSupabase ? window.VerdePath.getSupabase() : null;
    if (!sb) throw new Error('Supabase client not initialized');

    // Secure AI endpoints to logged in users to save credits
    const { data: { session } } = await sb.auth.getSession();
    if (!session) {
      throw new Error("Please Sign In or Create an Account to use the VerdePath AI Eco-Advisor.");
    }

    try {
      // Use supabase.functions.invoke which automatically adds auth headers
      const { data, error } = await sb.functions.invoke('ai-advisor', {
        body: payload
      });
      
      if (error) throw error;
      if (data && data.error) throw new Error(data.error);

      return data.message;
    } catch (err) {
      console.error('AI Advisor error:', err);
      // Fallback for demo if function isn't deployed
      throw new Error("I couldn't connect to the AI brain right now. Please tell the devs to check the Edge Function deployment.");
    }
  }

  /**
   * Get advice on specific routes
   */
  async function getRouteAdvice(routeData) {
    return callAdvisor({
      type: 'route_advice',
      routeData: JSON.stringify(routeData)
    });
  }

  /**
   * Get high-level analysis of fleet stats
   */
  async function getFleetAnalysis(fleetStats) {
    return callAdvisor({
      type: 'fleet_analysis',
      fleetStats: JSON.stringify(fleetStats)
    });
  }

  /**
   * Send a free-form chat message
   */
  async function askAdvisor(question, contextData = {}) {
    return callAdvisor({
      type: 'chat',
      userQuestion: question,
      routeData: JSON.stringify(contextData)
    });
  }

  // Typewriter effect helper
  function typeWriterEffect(element, text, speed = 25) {
    element.innerHTML = '';
    let i = 0;
    element.style.display = 'block';
    
    return new Promise(resolve => {
      function type() {
        if (i < text.length) {
          element.innerHTML += text.charAt(i);
          i++;
          setTimeout(type, speed);
        } else {
          resolve();
        }
      }
      type();
    });
  }

  // Expose globally
  window.VerdePath = window.VerdePath || {};
  Object.assign(window.VerdePath, {
    getRouteAdvice,
    getFleetAnalysis,
    askAdvisor,
    typeWriterEffect
  });

})();
