let currentPage = 1;
const ITEMS_PER_PAGE = 10;
let currentUserId = null;
let allLeaderboardData = [];

document.addEventListener('DOMContentLoaded', async () => {
    // Auth Check
    const { data: { user } } = await supabase.auth.getUser();
    if (user) {
        currentUserId = user.id;
    }

    await fetchFullLeaderboard();
    setupRealtimeSubscription();
});

async function fetchFullLeaderboard() {
    try {
        const { data, error } = await supabase
            .from('leaderboard')
            .select('*')
            .order('total_co2_saved_kg', { ascending: false });

        if (error) {
            console.warn("Error fetching leaderboard:", error);
        }

        const fetchedData = data || [];
        const researchedData = [
            { id: 'mock1', company_name: 'Amazon Fleet', total_routes: 450000, total_co2_saved_kg: 950000, green_score_avg: 98, badge_level: 'platinum' },
            { id: 'mock2', company_name: 'DHL Express', total_routes: 320000, total_co2_saved_kg: 820000, green_score_avg: 95, badge_level: 'platinum' },
            { id: 'mock3', company_name: 'FedEx Sustainability', total_routes: 280000, total_co2_saved_kg: 710000, green_score_avg: 92, badge_level: 'gold' },
            { id: 'mock4', company_name: 'UPS Green', total_routes: 210000, total_co2_saved_kg: 590000, green_score_avg: 89, badge_level: 'gold' },
            { id: 'mock5', company_name: 'IKEA Logistics', total_routes: 150000, total_co2_saved_kg: 420000, green_score_avg: 88, badge_level: 'gold' },
            { id: 'mock6', company_name: 'Walmart Transport', total_routes: 110000, total_co2_saved_kg: 330000, green_score_avg: 85, badge_level: 'silver' },
            { id: 'mock7', company_name: 'Maersk Line', total_routes: 80000, total_co2_saved_kg: 250000, green_score_avg: 81, badge_level: 'silver' },
            { id: 'mock8', company_name: 'DB Schenker', total_routes: 60000, total_co2_saved_kg: 180000, green_score_avg: 79, badge_level: 'silver' },
            { id: 'mock9', company_name: 'Kuehne+Nagel', total_routes: 40000, total_co2_saved_kg: 120000, green_score_avg: 75, badge_level: 'bronze' },
            { id: 'mock10', company_name: 'XPO Logistics', total_routes: 25000, total_co2_saved_kg: 90000, green_score_avg: 72, badge_level: 'bronze' }
        ];

        allLeaderboardData = [...researchedData, ...fetchedData].sort((a,b) => (b.total_co2_saved_kg || 0) - (a.total_co2_saved_kg || 0));
        
        renderLeaderboard();
        updatePersonalRankCard();
    } catch (err) {
        console.error("Error fetching leaderboard:", err);
    }
}

function renderLeaderboard() {
    // 1. Render Podium (Always Top 3 from the entire dataset)
    if (allLeaderboardData.length >= 3) {
        renderPodium(0, 'podium-1', 1); // 1st Place
        renderPodium(1, 'podium-2', 2); // 2nd Place
        renderPodium(2, 'podium-3', 3); // 3rd Place
    }

    // 2. Render Table based on pagination
    const tbody = document.getElementById('leaderboard-tbody');
    tbody.innerHTML = '';

    // Calculate pagination slice
    // On page 1, we show ranks 4 to 10.
    // On page 2, we show ranks 11 to 20, etc.
    let startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
    let endIndex = startIndex + ITEMS_PER_PAGE;
    
    // Adjust for first page so we skip the top 3 already in podium
    if (currentPage === 1) {
        startIndex = 3; 
    }

    const tableData = allLeaderboardData.slice(startIndex, endIndex);

    if (tableData.length === 0 && currentPage > 1) {
        tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;">No more entries.</td></tr>';
    } else {
        tableData.forEach((row, rawIndex) => {
            const rank = startIndex + rawIndex + 1;
            const tr = document.createElement('tr');
            
            // Highlight current user
            if (currentUserId && row.user_id === currentUserId) {
                tr.classList.add('row-current-user');
            }

            // Pseudo-random trend based on company name
            const trend = getTrend(row.company_name || 'User');
            
            // Badge visual
            const badgeMap = {
                'bronze': '🥉 Bronze',
                'silver': '🥈 Silver',
                'gold': '🥇 Gold',
                'platinum': '💎 Platinum'
            };

            const isYou = (currentUserId && row.user_id === currentUserId) ? '<span class="you-chip">YOU</span>' : '';

            tr.innerHTML = `
                <td><strong>#${rank}</strong></td>
                <td>${row.company_name || 'Anonymous Fleet'} ${isYou}</td>
                <td><span class="badge" style="background: rgba(255,255,255,0.1); padding: 4px 8px; border-radius: 12px; font-size: 0.8rem;">${badgeMap[row.badge_level] || 'Bronze'}</span></td>
                <td>${row.total_routes || 0}</td>
                <td style="color: var(--accent); font-weight: bold;">${(row.total_co2_saved_kg || 0).toFixed(1)} kg</td>
                <td>${(row.green_score_avg || 0).toFixed(1)}</td>
                <td class="${trend.class}"><strong>${trend.icon}</strong></td>
            `;
            tbody.appendChild(tr);
        });
    }

    // Handle Pagination Controls
    const totalPages = Math.ceil(allLeaderboardData.length / ITEMS_PER_PAGE);
    const paginationControls = document.getElementById('pagination-controls');
    
    if (totalPages > 1) {
        paginationControls.style.display = 'block';
        document.getElementById('page-indicator').textContent = `Page ${currentPage} of ${totalPages}`;
        
        document.getElementById('btn-prev-page').disabled = currentPage === 1;
        document.getElementById('btn-prev-page').onclick = () => {
            if (currentPage > 1) {
                currentPage--;
                renderLeaderboard();
            }
        };

        document.getElementById('btn-next-page').disabled = currentPage === totalPages;
        document.getElementById('btn-next-page').onclick = () => {
            if (currentPage < totalPages) {
                currentPage++;
                renderLeaderboard();
            }
        };
    } else {
        paginationControls.style.display = 'none';
    }
}

function renderPodium(dataIndex, elementId, rankNumber) {
    const el = document.getElementById(elementId);
    if (!el) return;
    
    el.classList.remove('skeleton');
    const row = allLeaderboardData[dataIndex];
    if (!row) {
        el.innerHTML = `<div class="rank">#${rankNumber}</div><div class="company">-</div>`;
        return;
    }

    const badgeIcons = { 'bronze': '🥉', 'silver': '🥈', 'gold': '🥇', 'platinum': '💎' };
    
    el.innerHTML = `
        <div class="rank">#${rankNumber}</div>
        <div class="company">${row.company_name || 'Anonymous Fleet'}</div>
        <div class="co2">${(row.total_co2_saved_kg || 0).toFixed(1)} kg CO₂ Saved</div>
        <div class="badge">${badgeIcons[row.badge_level] || '🥉'} Score: ${(row.green_score_avg || 0).toFixed(1)}</div>
    `;
}

function getTrend(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
        hash = str.charCodeAt(i) + ((hash << 5) - hash);
    }
    const val = Math.abs(hash) % 4;
    if (val === 0) return { icon: '↑↑', class: 'trend-up' };
    if (val === 1) return { icon: '↑', class: 'trend-up' };
    if (val === 2) return { icon: '↓', class: 'trend-down' };
    return { icon: '—', class: 'trend-flat' };
}

function updatePersonalRankCard() {
    const card = document.getElementById('personal-rank-card');
    if (!currentUserId) return;

    const myIndex = allLeaderboardData.findIndex(r => r.user_id === currentUserId);
    
    if (myIndex === -1) {
        document.getElementById('my-rank-pos').textContent = 'Unranked';
        document.getElementById('my-rank-progress').textContent = 'Complete your first route to join the leaderboard!';
    } else {
        const myRank = myIndex + 1;
        const myData = allLeaderboardData[myIndex];
        document.getElementById('my-rank-pos').textContent = `#${myRank}`;
        
        let nextTarget = '';
        let missingCo2 = 0;
        const currentCo2 = myData.total_co2_saved_kg || 0;

        if (currentCo2 < 10) {
            missingCo2 = 10 - currentCo2;
            nextTarget = 'Silver';
        } else if (currentCo2 < 100) {
            missingCo2 = 100 - currentCo2;
            nextTarget = 'Gold';
        } else if (currentCo2 < 500) {
            missingCo2 = 500 - currentCo2;
            nextTarget = 'Platinum';
        } else {
            nextTarget = 'Top Tier';
        }

        if (nextTarget === 'Top Tier') {
            document.getElementById('my-rank-progress').textContent = `You are in the top tier! Keep saving CO₂ to maintain your lead.`;
        } else {
            document.getElementById('my-rank-progress').innerHTML = `You need <strong>${missingCo2.toFixed(1)} kg</strong> more CO₂ saved to reach ${nextTarget} badge.`;
        }
    }

    card.classList.add('active');
}

function setupRealtimeSubscription() {
    supabase.channel('leaderboard-changes')
        .on(
            'postgres_changes',
            { event: '*', schema: 'public', table: 'leaderboard' },
            (payload) => {
                showLiveToast();
                // Flash animation for the table body can be rough, so we just re-fetch and add class to tbody elements briefly
                fetchFullLeaderboard().then(() => {
                    const rows = document.querySelectorAll('#leaderboard-tbody tr');
                    rows.forEach(r => {
                        r.classList.add('flash-green');
                        setTimeout(() => r.classList.remove('flash-green'), 1000);
                    });
                });
            }
        )
        .subscribe();
}

function showLiveToast() {
    const toast = document.getElementById('live-toast');
    toast.classList.add('show');
    setTimeout(() => {
        toast.classList.remove('show');
    }, 3000);
}
