/* ============================================
   VerdePath — Charts JS
   Chart.js wrappers for the Fleet Dashboard
   ============================================ */

(function initCharts() {
  'use strict';

  // Make sure Chart.js is loaded
  if (typeof Chart === 'undefined') {
    console.error('Chart.js is not loaded.');
    return;
  }

  // --- Default Chart.js Settings for Dark Theme ---
  Chart.defaults.color = 'rgba(255, 255, 255, 0.6)';
  Chart.defaults.font.family = "'DM Sans', sans-serif";
  Chart.defaults.plugins.tooltip.backgroundColor = 'rgba(10, 22, 40, 0.9)';
  Chart.defaults.plugins.tooltip.titleColor = '#fff';
  Chart.defaults.plugins.tooltip.bodyColor = '#fff';
  Chart.defaults.plugins.tooltip.borderColor = 'rgba(255, 255, 255, 0.1)';
  Chart.defaults.plugins.tooltip.borderWidth = 1;
  Chart.defaults.plugins.tooltip.padding = 10;
  Chart.defaults.plugins.tooltip.cornerRadius = 8;
  Chart.defaults.plugins.legend.labels.color = 'rgba(255, 255, 255, 0.7)';

  const gridConfig = {
    color: 'rgba(255, 255, 255, 0.05)',
    tickColor: 'transparent'
  };

  /**
   * Initialize the monthly emissions vs savings line chart
   */
  function initLineChart(canvasId, labels, emittedData, savedData) {
    const ctx = document.getElementById(canvasId).getContext('2d');

    // Create a gradient for the filled area (Savings)
    const gradientGreen = ctx.createLinearGradient(0, 0, 0, 400);
    gradientGreen.addColorStop(0, 'rgba(0, 255, 136, 0.4)');
    gradientGreen.addColorStop(1, 'rgba(0, 255, 136, 0.0)');

    return new Chart(ctx, {
      type: 'line',
      data: {
        labels: labels,
        datasets: [
          {
            label: 'CO₂ Emitted (kg)',
            data: emittedData,
            borderColor: '#fbbf24', // Amber
            backgroundColor: 'transparent',
            borderWidth: 2,
            tension: 0.4, // smooth curves
            pointBackgroundColor: '#fbbf24',
            pointBorderColor: '#000',
            pointBorderWidth: 2,
            pointRadius: 4,
            pointHoverRadius: 6,
            fill: false
          },
          {
            label: 'CO₂ Saved (kg)',
            data: savedData,
            borderColor: '#00ff88', // Green
            backgroundColor: gradientGreen,
            borderWidth: 2,
            tension: 0.4,
            pointBackgroundColor: '#00ff88',
            pointBorderColor: '#000',
            pointBorderWidth: 2,
            pointRadius: 4,
            pointHoverRadius: 6,
            fill: true
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: {
          mode: 'index',
          intersect: false,
        },
        plugins: {
          legend: {
            position: 'bottom',
            labels: { usePointStyle: true, boxWidth: 8 }
          }
        },
        scales: {
          x: { grid: { display: false } },
          y: { 
            grid: gridConfig,
            beginAtZero: true
          }
        },
        animation: {
          y: { duration: 1000, easing: 'easeOutQuart' }
        }
      }
    });
  }

  /**
   * Initialize the emissions by vehicle type doughnut chart
   */
  function initDoughnutChart(canvasId, labels, data, colors) {
    const ctx = document.getElementById(canvasId).getContext('2d');

    return new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: labels,
        datasets: [{
          data: data,
          backgroundColor: colors,
          borderColor: '#0a1628', // Match background to act as gap
          borderWidth: 2,
          hoverOffset: 4
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '75%', // Make it thin
        plugins: {
          legend: {
            position: 'bottom',
            labels: { usePointStyle: true, boxWidth: 8, padding: 20 }
          }
        },
        animation: {
          animateScale: true,
          animateRotate: true,
          duration: 1200,
          easing: 'easeOutQuart'
        }
      }
    });
  }

  /**
   * Helper to update an existing chart with new data
   */
  function updateChart(chart, newLabels, newDatasetsData) {
    if (!chart) return;
    if (newLabels) chart.data.labels = newLabels;
    if (newDatasetsData && Array.isArray(newDatasetsData)) {
      chart.data.datasets.forEach((dataset, i) => {
        if (newDatasetsData[i]) {
          dataset.data = newDatasetsData[i];
        }
      });
    }
    chart.update();
  }

  // Expose globally
  window.VerdePath = window.VerdePath || {};
  Object.assign(window.VerdePath, {
    initLineChart,
    initDoughnutChart,
    updateChart
  });

})();
