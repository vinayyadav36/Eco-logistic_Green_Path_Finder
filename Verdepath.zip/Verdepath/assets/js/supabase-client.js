/* ============================================
   VerdePath — Supabase Client
   Initialization + auth helpers + profile helpers
   ============================================ */

// ⚠️ Replace these with your actual Supabase project credentials
// Find them at: https://supabase.com/dashboard/project/_/settings/api
const SUPABASE_URL = 'https://iyjbopudpzdobpbiiiro.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Iml5amJvcHVkcHpkb2JwYmlpaXJvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzM4MTQ5NTcsImV4cCI6MjA4OTM5MDk1N30.S5tfRXwYVWNr5qTjHqXeOZEQ7r4C5KTUhXJev5EsEKE';

// 🎯 DEMO MODE FLAG
window.DEMO_MODE = true;

// Initialize Supabase client (loaded via CDN in HTML)
// <script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
let _supabaseClient = null;

function getSupabase() {
  if (!_supabaseClient) {
    if (typeof supabase === 'undefined' || !supabase.createClient) {
      console.error('Supabase JS SDK not loaded. Add the CDN script to your HTML.');
      return null;
    }
    _supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
  }
  return _supabaseClient;
}

// ---- Auth Helpers ----

/**
 * Get the currently logged-in user (or null)
 */
async function getCurrentUser() {
  const sb = getSupabase();
  if (!sb) return null;
  const { data: { user }, error } = await sb.auth.getUser();
  if (error) {
    console.warn('getCurrentUser error:', error.message);
    return null;
  }
  return user;
}

/**
 * Sign in with email and password
 */
async function signIn(email, password) {
  const sb = getSupabase();
  if (!sb) throw new Error('Supabase not initialized');

  const { data, error } = await sb.auth.signInWithPassword({ email, password });
  if (error) throw error;

  // Redirect to dashboard on success
  window.location.href = 'dashboard.html';
  return data;
}

/**
 * Sign up a new user
 */
async function signUp(email, password, fullName, companyName, fleetSize) {
  const sb = getSupabase();
  if (!sb) throw new Error('Supabase not initialized');

  const { data, error } = await sb.auth.signUp({
    email,
    password,
    options: {
      data: {
        full_name: fullName,
        company_name: companyName,
        fleet_size: fleetSize || 1
      }
    }
  });
  if (error) throw error;

  // If auto-confirm is on, update profile with company info
  if (data.user) {
    const sb2 = getSupabase();
    await sb2.from('profiles').update({
      company_name: companyName,
      fleet_size: fleetSize || 1
    }).eq('id', data.user.id);
  }

  // Redirect to route planner
  window.location.href = 'app.html';
  return data;
}

/**
 * Sign out the current user
 */
async function signOut() {
  const sb = getSupabase();
  if (!sb) return;
  const { error } = await sb.auth.signOut();
  if (error) console.error('Sign out error:', error.message);
  window.location.href = 'index.html';
}

// ---- Profile Helpers ----

/**
 * Get user profile by user ID
 */
async function getProfile(userId) {
  const sb = getSupabase();
  if (!sb) return null;

  const { data, error } = await sb
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .single();

  if (error) {
    console.warn('getProfile error:', error.message);
    return null;
  }
  return data;
}

/**
 * Update user profile
 */
async function updateProfile(userId, updates) {
  const sb = getSupabase();
  if (!sb) throw new Error('Supabase not initialized');

  const { data, error } = await sb
    .from('profiles')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', userId)
    .select()
    .single();

  if (error) throw error;
  return data;
}

// ---- Auth Guard ----

/**
 * Require authentication — redirects to index.html if not logged in
 */
async function requireAuth() {
  const user = await getCurrentUser();
  if (!user) {
    window.location.href = 'index.html#auth-modal';
    return null;
  }
  return user;
}

// ---- Route Data Helpers ----

/**
 * Save a route to the database
 */
async function saveRoute(routeData) {
  const sb = getSupabase();
  if (!sb) throw new Error('Supabase not initialized');

  const user = await getCurrentUser();
  if (!user) throw new Error('Not authenticated');

  const { data, error } = await sb
    .from('routes')
    .insert({
      user_id: user.id,
      ...routeData
    })
    .select()
    .single();

  if (error) throw error;
  return data;
}

/**
 * Get user's route history
 */
async function getRouteHistory(limit = 20) {
  if (window.DEMO_MODE) return generateMockRoutes(limit);

  const sb = getSupabase();
  if (!sb) return [];

  const user = await getCurrentUser();
  if (!user) return [];

  const { data, error } = await sb
    .from('routes')
    .select('*')
    .eq('user_id', user.id)
    .order('created_at', { ascending: false })
    .limit(limit);

  if (error) {
    console.warn('getRouteHistory error:', error.message);
    return [];
  }
  return data;
}

/**
 * Get fleet stats for the current user
 */
async function getFleetStats() {
  if (window.DEMO_MODE) return generateMockFleetStats();

  const sb = getSupabase();
  if (!sb) return [];

  const user = await getCurrentUser();
  if (!user) return [];

  const { data, error } = await sb
    .from('fleet_stats')
    .select('*')
    .eq('user_id', user.id)
    .order('month', { ascending: false });

  if (error) {
    console.warn('getFleetStats error:', error.message);
    return [];
  }
  return data;
}

/**
 * Get the public leaderboard
 */
async function getLeaderboard(limit = 10) {
  const sb = getSupabase();
  if (!sb) return [];

  const { data, error } = await sb
    .from('leaderboard')
    .select('*')
    .order('total_co2_saved_kg', { ascending: false })
    .limit(limit);

  if (error) {
    console.warn('getLeaderboard error:', error.message);
    return [];
  }
  return data;
}

// Make functions globally available (vanilla JS, no module bundler)
window.VerdePath = window.VerdePath || {};
Object.assign(window.VerdePath, {
  getSupabase,
  getCurrentUser,
  signIn,
  signUp,
  signOut,
  getProfile,
  updateProfile,
  requireAuth,
  saveRoute,
  getRouteHistory,
  getFleetStats,
  getLeaderboard
});

// ==== DEMO MODE HELPERS ====

function generateMockRoutes(limit) {
    const vehicles = ['van', 'truck', 'ev_van', 'car', 'motorbike'];
    const routes = [];
    const now = new Date();
    for(let i=0; i<limit; i++) {
        const d = new Date(now);
        d.setDate(d.getDate() - (i * 2)); 
        routes.push({
            id: `mock-route-${i}`,
            origin: `Location A-${i}`,
            destination: `Location B-${i}`,
            distance_km: Math.floor(Math.random() * 80) + 10,
            co2_kg: Math.floor(Math.random() * 25) + 2,
            green_score: Math.floor(Math.random() * 40) + 60,
            vehicle_type: vehicles[i % vehicles.length],
            created_at: d.toISOString()
        });
    }
    return routes;
}

function generateMockFleetStats() {
    const now = new Date();
    const currentMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
    const prevMonth = `${now.getFullYear()}-${String(now.getMonth() === 0 ? 12 : now.getMonth()).padStart(2, '0')}`;
    const olderMonth = `${now.getFullYear()}-${String(now.getMonth() === 0 ? 11 : now.getMonth() - 1).padStart(2, '0')}`;
    return [
        { month: currentMonth, total_routes: 45, total_co2_kg: 850, total_distance_km: 1200, co2_saved_vs_baseline_kg: 150, green_score_avg: 82 },
        { month: prevMonth, total_routes: 38, total_co2_kg: 920, total_distance_km: 1050, co2_saved_vs_baseline_kg: 90, green_score_avg: 75 },
        { month: olderMonth, total_routes: 42, total_co2_kg: 950, total_distance_km: 1100, co2_saved_vs_baseline_kg: 110, green_score_avg: 78 }
    ];
}

function initDemoBanner() {
    if (!window.DEMO_MODE) return;
    
    const banner = document.createElement('div');
    banner.className = 'glass-panel';
    banner.style.position = 'fixed';
    banner.style.bottom = '90px'; // Give room for AI widget or other elements
    banner.style.right = '20px';
    banner.style.zIndex = '9999';
    banner.style.display = 'flex';
    banner.style.alignItems = 'center';
    banner.style.gap = '15px';
    banner.style.padding = '12px 20px';
    banner.style.background = 'rgba(243, 156, 18, 0.15)';
    banner.style.border = '1px solid rgba(243, 156, 18, 0.5)';
    banner.style.borderLeft = '4px solid #f39c12';
    
    banner.innerHTML = `
        <div>
            <strong style="color: #f39c12; display: flex; align-items: center; gap: 6px;">
                <i class="ph ph-target"></i> Demo Mode
            </strong>
            <span style="font-size: 0.85rem; color: var(--text-muted);">Showing sample data</span>
        </div>
        <button id="toggle-live-btn" class="btn btn-outline" style="padding: 4px 12px; font-size: 0.85rem; border-color: rgba(243, 156, 18, 0.5); color: #f39c12;">
            Switch to Live Mode
        </button>
    `;
    
    document.body.appendChild(banner);

    document.getElementById('toggle-live-btn').addEventListener('click', async () => {
        const user = await getCurrentUser();
        if (!user) {
            // Check if openAuthModal exists in current context
            if (typeof window.openAuthModal === 'function') {
                window.openAuthModal();
            } else {
                window.location.href = 'index.html#auth-modal';
            }
        } else {
            window.DEMO_MODE = false;
            banner.style.display = 'none';
            // Reload page to fetch real data
            window.location.reload();
        }
    });
}

document.addEventListener('DOMContentLoaded', initDemoBanner);
