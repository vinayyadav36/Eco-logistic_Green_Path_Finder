# 🌿 VerdePath — Green Logistics Intelligence Platform
### Samsung Innovation Campus Hackathon · Coding & Programming · Haryana Regional

---

## 🧭 Why This Wins at Samsung

Samsung's judging criteria (from Solve for Tomorrow / SIC Hackathons) weights:
1. **Innovation & Creativity** — Uniqueness, novel problem definition, use of technology
2. **Impact & Feasibility** — Real-world scalability, data-backed urgency
3. **Technical Execution** — Working prototype, clear architecture, algorithms used
4. **Scalability** — Can it grow to serve more users / geographies

**Why VerdePath scores high on all 4:**
- Logistics = **10% of India's total carbon emissions** (verifiable stat to quote in pitch)
- Last-mile delivery = **51% of total delivery CO₂** — this is the problem nobody has solved at the SMB level
- Last-mile delivery vehicles are cited by **78% of residents** in Delhi/Mumbai as a top pollution source
- Urban delivery emissions projected to rise **60% by 2030** under BAU scenario
- This is Samsung's *own sustainability theme* — they are committed to net-zero, they will love a tool that helps

---

## 📌 Problem Statement

Delivery and logistics companies — especially small fleets operating within Haryana/NCR — have **zero accessible tooling** to:
- Measure the actual CO₂ footprint of their routes
- Compare routes by environmental impact (not just speed/distance)
- Track fleet-level sustainability over time
- Demonstrate green credentials to eco-conscious customers

Tools like Google Maps optimize for time. Tools like Here Maps optimize for toll cost. **Nobody optimizes for the planet.**

**Statistic to lead with in pitch:**
> Road transportation accounts for over 70% of India's total freight transit. Last-mile delivery alone generates an estimated 5,00,000 tonnes of CO₂ annually from 2.6 billion parcels.

---

## 💡 Proposed Solution: VerdePath

A **web platform** that acts as a smart green logistics co-pilot:
- **Route Planner** — Compare multiple routes with CO₂, fuel cost, and green score
- **Fleet Dashboard** — Track emissions history, savings, and carbon credit estimates
- **AI Eco-Advisor** — Natural language assistant that gives route tips and suggestions
- **Leaderboard / Gamification** — Compete with other fleets on green score (Supabase-powered)
- **EV Integration** — Flag routes where electric vehicle switch saves X kg CO₂
- **Carbon Report Export** — PDF report to share with customers or investors

---

## 🔑 Innovation Additions (Beyond Original Idea)

| Feature | Why it's innovative |
|---|---|
| **AI Eco-Advisor (Claude API)** | Natural language tips: "Switch to EV on this route to save 4.2 kg CO₂" |
| **Green Score Leaderboard** | Gamification across fleets using Supabase real-time — viral, shareable |
| **Carbon Credit Estimator** | Converts CO₂ saved into estimated credit value (₹) — business incentive |
| **Multi-Stop Route Optimizer** | Dijkstra + greedy algorithm for multi-delivery run optimization |
| **Time-of-Day Routing** | Route scores change by traffic hour — morning vs evening emissions differ |
| **Haryana EV Charging Map** | Integration to show nearby EV charging on the route |
| **Customer Green Badge** | Shareable badge: "Your order was delivered via a green route saving X gCO₂" |

---

## 🏗️ Project File Structure

```
ecroute/
├── PRD.md                          ← YOU ARE HERE (master reference)
├── index.html                      ← Landing page / hero
├── app.html                        ← Main route planner app
├── dashboard.html                  ← Fleet emissions dashboard
├── leaderboard.html                ← Green leaderboard (Supabase real-time)
├── report.html                     ← Carbon report generator
│
├── assets/
│   ├── css/
│   │   ├── global.css              ← CSS variables, glassmorphism base, fonts
│   │   ├── components.css          ← Cards, buttons, inputs, badges
│   │   └── animations.css         ← Particle effects, reveal animations
│   ├── js/
│   │   ├── supabase-client.js      ← Supabase init + auth helpers
│   │   ├── route-engine.js         ← Dijkstra algorithm + emission calc
│   │   ├── emission-factors.js     ← CO₂ factors by vehicle type (standard data)
│   │   ├── map-controller.js       ← Leaflet.js map logic
│   │   ├── ai-advisor.js           ← Claude API calls for eco tips
│   │   ├── charts.js               ← Chart.js dashboard visualizations
│   │   └── auth.js                 ← Login/signup flows
│   └── img/
│       └── logo.svg
│
├── supabase/
│   ├── schema.sql                  ← All table definitions
│   ├── rls-policies.sql            ← Row Level Security policies
│   └── edge-functions/
│       ├── calculate-route/        ← Route calculation edge function
│       │   └── index.ts
│       ├── ai-advisor/             ← Claude API proxy edge function
│       │   └── index.ts
│       └── generate-report/        ← PDF report generation
│           └── index.ts
│
└── README.md
```

---

## 🗄️ Supabase Database Schema

### Table: `users`
```sql
id uuid primary key default gen_random_uuid()
email text unique not null
full_name text
company_name text
fleet_size int default 1
created_at timestamptz default now()
```

### Table: `routes`
```sql
id uuid primary key default gen_random_uuid()
user_id uuid references users(id)
origin text not null
destination text not null
origin_lat float, origin_lng float
dest_lat float, dest_lng float
vehicle_type text  -- 'bike' | 'car' | 'van' | 'truck' | 'ev'
distance_km float
fuel_used_liters float
co2_kg float
green_score float
route_data jsonb  -- full route geometry + waypoints
created_at timestamptz default now()
```

### Table: `fleet_stats`
```sql
id uuid primary key default gen_random_uuid()
user_id uuid references users(id)
month text  -- 'YYYY-MM'
total_routes int
total_co2_kg float
total_distance_km float
co2_saved_vs_baseline_kg float
green_score_avg float
```

### Table: `leaderboard`
```sql
id uuid primary key default gen_random_uuid()
user_id uuid references users(id)
company_name text
total_co2_saved_kg float
green_score_avg float
badge_level text  -- 'bronze' | 'silver' | 'gold' | 'platinum'
updated_at timestamptz default now()
```

---

## ⚙️ Emission Calculation Logic

### Vehicle Emission Factors (Standard, sourced from IPCC / MoEFCC India)

| Vehicle | Fuel Type | CO₂ per km (kg) | Fuel per km (L) |
|---|---|---|---|
| Bicycle | None | 0 | 0 |
| Motorbike | Petrol | 0.103 | 0.043 |
| Car | Petrol | 0.192 | 0.08 |
| Delivery Van | Diesel | 0.270 | 0.108 |
| Truck (HGV) | Diesel | 0.620 | 0.248 |
| EV Car | Electric | 0.053 | — |
| EV Van | Electric | 0.089 | — |

### Green Score Formula
```
Traffic Multiplier:
  low = 1.0, medium = 1.3, high = 1.7

Green Score = Distance(km) × EmissionFactor(kg/km) × TrafficMultiplier
            × TimeOfDayFactor (peak=1.4, offpeak=1.0)

Lower Green Score = More Eco-Friendly
```

### CO₂ Saved vs Baseline
```
Baseline = same route using Diesel Van (worst common case)
Savings = Baseline_CO₂ - Actual_CO₂
Carbon Credit Value (₹) = Savings_kg × 0.001 (tonnes) × ₹500/tonne (India CBAM estimate)
```

---

## 🎨 Design System

### Aesthetic Direction: **Luxury Dark + Glassmorphism**
- **Theme**: Deep space dark backgrounds (#050d1a, #0a1628) with luminous green (#00ff88, #00d68f) accents
- **Glass Cards**: `backdrop-filter: blur(20px)` + `rgba(255,255,255,0.05)` backgrounds with subtle borders
- **Typography**: `Syne` (display/headings) + `DM Sans` (body) — both from Google Fonts
- **Animations**: Floating particles in background, staggered card reveals on scroll, smooth number counters
- **Map Style**: Dark map tiles (CartoDB Dark Matter) with glowing green route overlays
- **Gradients**: Mesh gradients using green → teal → blue-green
- **Accent Colors**:
  - Green (eco-friendly): `#00ff88`
  - Amber (moderate): `#fbbf24`
  - Red (high emission): `#f43f5e`
  - Blue (EV): `#38bdf8`

### Glassmorphism Base CSS
```css
.glass-card {
  background: rgba(255, 255, 255, 0.04);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  border: 1px solid rgba(0, 255, 136, 0.15);
  border-radius: 20px;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
}
```

---

## 🔌 MCP / External Integrations

### Supabase MCP (via Stitch by Google)
- Auth: Email + password signup/login
- Database: All tables above via Supabase client JS SDK
- Edge Functions: Route calculation, AI advisor proxy, report generation
- Storage: Save generated PDF reports

### Context7 MCP Usage
Use Context7 to read docs for:
- `leaflet.js` — map rendering
- `chart.js` — dashboard charts
- `supabase-js` — client SDK
- `@anthropic-ai/sdk` — for edge function AI calls

### Claude API (via Supabase Edge Function)
Used for the AI Eco-Advisor feature. The edge function acts as a secure proxy so the API key is never exposed in frontend.

---

## 📋 Pages Specification

### Page 1: `index.html` — Landing Page
**Sections:**
1. Hero — Animated headline, CTA "Plan Your Green Route", floating particles
2. Problem Stats — Animated counters: "10% of India's carbon emissions", "70% from road freight"
3. Features showcase — 6 glass cards with icons
4. How It Works — 4-step flow diagram
5. Leaderboard Preview — Top 3 green fleets
6. CTA + Footer

### Page 2: `app.html` — Route Planner
**Sections:**
1. Left Panel: Form inputs (origin, destination, vehicle type, time of day)
2. Center: Leaflet map (full height)
3. Right Panel: Route comparison cards (Route A / B / C) with green scores
4. Bottom: Emission breakdown + AI Eco-Advisor chat bubble

### Page 3: `dashboard.html` — Fleet Dashboard
**Sections:**
1. Stats row: Total CO₂ saved, routes planned, green score avg, carbon credits earned
2. Line chart: Monthly CO₂ trend
3. Bar chart: CO₂ by vehicle type
4. Recent routes table
5. Badge display

### Page 4: `leaderboard.html`
**Sections:**
1. Top 10 companies by CO₂ saved
2. Real-time updates via Supabase subscriptions
3. User's own rank highlight

---

## 🪜 Build Order (Step-by-Step Prompts Below)

1. **Step 1** — Global CSS + Design System (global.css, fonts, glassmorphism)
2. **Step 2** — Landing Page (index.html) — static, no backend
3. **Step 3** — Supabase schema + auth setup
4. **Step 4** — Route Planner page (app.html) — map + form UI (frontend only)
5. **Step 5** — Emission calculation engine (route-engine.js + emission-factors.js)
6. **Step 6** — Supabase integration — save routes, auth guard
7. **Step 7** — Fleet Dashboard (dashboard.html) with Chart.js
8. **Step 8** — AI Eco-Advisor (Edge Function + frontend chat UI)
9. **Step 9** — Leaderboard with real-time Supabase subscriptions
10. **Step 10** — Polish: animations, mobile responsiveness, final QA

---

## 🎯 Hackathon Pitch Talking Points

1. **Hook**: "In India, last-mile delivery contributes 5,00,000 tonnes of CO₂ per year. That's equivalent to entire small countries."
2. **Gap**: "Every logistics tool optimizes for time. Nobody optimizes for the planet."
3. **Solution**: Live demo of route comparison showing CO₂ savings
4. **Innovation**: AI Eco-Advisor + Carbon Credit Estimator — unique features
5. **Scale**: Works for any fleet, any city, any vehicle type. Supabase means it can scale to millions of users.
6. **Samsung Alignment**: Samsung's own net-zero goals + Samsung Innovation Campus = we built a tool Samsung itself could use for its logistics.

---

*Last updated: March 2026 | Team: [Your Team Name] | Samsung Innovation Campus Hackathon — Haryana*
