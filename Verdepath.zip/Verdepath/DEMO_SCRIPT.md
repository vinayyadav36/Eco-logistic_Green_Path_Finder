# VerdePath Pitch Demo Script

This script is designed to walk through the complete VerdePath experience in under 3 minutes, highlighting the core value propositions: simplicity, AI intelligence, and tangible carbon offset tracking.

---

## 🚀 Setup Before Demo
1. Ensure the local development server is running.
2. Ensure you have internet connection for the Groq AI, OSRM routing, and Supabase Database requests.
3. Open `http://localhost:5173/index.html` (or your local port).
4. Make sure you are logged out.

We built an automatic **Demo Mode** feature. On the dashboard and leaderboard, the app will automatically inject mock data if `DEMO_MODE=true` is set to showcase full historical stats without needing weeks of real-world usage.

---

## 🎬 1. The Hook (Landing Page)
*Start on `index.html`*

**Speaker:**
"Logistics and last-mile delivery are responsible for nearly 10% of India's carbon emissions. But fleet managers don't have the tools to measure, manage, or monetize these emissions. Welcome to VerdePath."

*Action: Scroll down slowly through the **Problem** and **Features** sections, pausing briefly on the vibrant glassmorphic UI.*

"VerdePath is an AI-powered route optimization intelligence platform. We don't just find the fastest route; we find the greenest route, calculate the exact CO₂ savings, and convert those savings into measurable carbon credits."

*Action: Click **"Start Planning →"** to navigate to the App.*

---

## 🗺️ 2. Route Planner & Intelligence
*Arrive at `app.html` – the core planner.*

**Speaker:**
"Let’s say I’m managing a delivery fleet in Delhi. I need to send a vehicle to Jaipur."

*Action:*
- *Type **"Delhi"** in the Starting Point.*
- *Type **"Jaipur"** in the Destination.*
- *Select **"Truck"** from the vehicle selector.*
- *Select **"Morning Peak"**.*
- *Click **"Calculate Green Routes"**.*

**Speaker:**
"Our engine uses OpenStreetMap OSRM to generate multiple routes. It then calculates real-time emissions based on the vehicle type, distance, and traffic conditions. 

As you can see, Route A is the fastest, but look at the difference if we switch the vehicle type."

*Action: Click **"EV Van"** on the left panel, then hit calculate again.*

"By switching to an electric vehicle, the system recalculates. Look at the recommendation box at the bottom."

*Action: Highlight the Recommendation Box.*

"VerdePath tells us exactly how much CO₂ we prevent—equivalent to over 200 trees—and even estimates the monetary value of those carbon credits in the current market."

---

## 🤖 3. AI Eco-Advisor
*Action: Click **"Ask AI Eco-Advisor"** at the bottom right of the planner to expand the panel.*

**Speaker:**
"But data alone isn't enough. We integrated a high-performance LLM (Llama 3 70B via Groq) as our Eco-Advisor."

*Action: The AI automatically types out a custom summary of the route.*
*Action: Type in the chat input: "What else can I do to reduce emissions on this highway route?"*

"Fleet managers can ask the AI for specific advice, like tire pressure optimization, driver behavior adjustments, or charging station strategies for this specific route. It's like having a sustainability consultant in your pocket."

---

## 📊 4. The Impact Tracking (Dashboard)
*Action: Click **"Dashboard"** in the top navigation.*
*(Note: If prompted, quickly use the dummy Sign In. However, Demo Mode will show a yellow banner at the bottom indicating sample data is active).*

**Speaker:**
"Once a route is completed, it's saved to the fleet's history. Over time, calculating one route doesn't mean much, but aggregating thousands of deliveries changes everything. This is the Fleet Dashboard."

*Action: Scroll to show the top stats counting up, the charts, and the badges.*

"Here, companies can track their total CO₂ saved, their total carbon credit value, and analyze trends over time. We gamify sustainability—fleets unlock badges like Silver, Gold, and Platinum as they hit major emission reduction milestones."

*Action: Point out the AI analysis box on the dashboard.*

"The AI runs a constant analysis on your entire fleet operations, pointing out inefficiencies like 'Your trucks are emitting 60% of your total footprint despite handling only 30% of your routes.'"

---

## 🏆 5. The Leaderboard
*Action: Click **"Leaderboard"** in the top navigation.*

**Speaker:**
"Finally, sustainability should be public. The Green Fleet Leaderboard ranks companies based on their total CO₂ saved."

*Action: Scroll through the podium and the striped table of top companies.*

"This creates healthy industry competition. Companies can boast about their VerdePath Green Score to clients and investors. Over time, VerdePath isn't just a routing tool; it's the standard for green logistics certification."

**End of Demo.**
"Thank you. We are VerdePath."
