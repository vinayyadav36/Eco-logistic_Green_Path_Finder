-- ============================================
-- VerdePath — Supabase Database Schema
-- All table definitions, RLS policies, triggers
-- ============================================

-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- ============================================
-- TABLES
-- ============================================

-- Users profile table (extends Supabase auth.users)
create table public.profiles (
  id uuid references auth.users(id) on delete cascade primary key,
  email text,
  full_name text,
  company_name text,
  fleet_size int default 1,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- Routes table
create table public.routes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,
  origin text not null,
  destination text not null,
  origin_lat float,
  origin_lng float,
  dest_lat float,
  dest_lng float,
  vehicle_type text check (vehicle_type in ('bike','motorbike','car','van','truck','ev_car','ev_van')),
  distance_km float,
  fuel_used_liters float,
  co2_kg float,
  green_score float,
  traffic_level text check (traffic_level in ('low','medium','high')),
  route_data jsonb,
  created_at timestamptz default now()
);

-- Fleet monthly stats (aggregated)
create table public.fleet_stats (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,
  month text,
  total_routes int default 0,
  total_co2_kg float default 0,
  total_distance_km float default 0,
  co2_saved_vs_baseline_kg float default 0,
  green_score_avg float default 0,
  unique (user_id, month)
);

-- Leaderboard (public read)
create table public.leaderboard (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade unique,
  company_name text,
  total_co2_saved_kg float default 0,
  total_routes int default 0,
  green_score_avg float default 0,
  badge_level text default 'bronze',
  updated_at timestamptz default now()
);

-- ============================================
-- ROW LEVEL SECURITY
-- ============================================

alter table public.profiles enable row level security;
alter table public.routes enable row level security;
alter table public.fleet_stats enable row level security;
alter table public.leaderboard enable row level security;

-- Profiles: users can only see/edit their own
create policy "Users can view own profile"
  on public.profiles for select
  using (auth.uid() = id);

create policy "Users can update own profile"
  on public.profiles for update
  using (auth.uid() = id);

create policy "Users can insert own profile"
  on public.profiles for insert
  with check (auth.uid() = id);

-- Routes: users can only see/create their own
create policy "Users can view own routes"
  on public.routes for select
  using (auth.uid() = user_id);

create policy "Users can insert own routes"
  on public.routes for insert
  with check (auth.uid() = user_id);

-- Fleet stats: users can only see their own
create policy "Users can view own stats"
  on public.fleet_stats for select
  using (auth.uid() = user_id);

-- Leaderboard: everyone can read, only own row can update
create policy "Leaderboard is public"
  on public.leaderboard for select
  using (true);

create policy "Users update own leaderboard"
  on public.leaderboard for all
  using (auth.uid() = user_id);

-- ============================================
-- TRIGGER: Auto-create profile on signup
-- ============================================

create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, email, full_name)
  values (new.id, new.email, new.raw_user_meta_data->>'full_name');
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();
