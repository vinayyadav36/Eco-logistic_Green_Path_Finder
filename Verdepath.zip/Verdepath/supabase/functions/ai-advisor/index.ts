import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req: Request) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { type, routeData, fleetStats, userQuestion } = await req.json();
    const groqKey = Deno.env.get('GROQ_API_KEY');

    if (!groqKey) {
      throw new Error("Missing GROQ_API_KEY environment variable");
    }

    let userMessage = "";

    if (type === 'route_advice') {
      userMessage = `Here are the route options: ${routeData}. Which is greenest and why? What specific action should the fleet manager take?`;
    } else if (type === 'fleet_analysis') {
      userMessage = `Here are my fleet stats for this month: ${fleetStats}. Give me a 3-sentence analysis with the top action I should take.`;
    } else if (type === 'chat') {
      userMessage = `User question: "${userQuestion}". Context routes/stats: ${routeData || 'none'}.`;
    } else {
      throw new Error(`Unknown request type: ${type}`);
    }

    const payload = {
      model: "llama3-70b-8192",
      max_tokens: 500,
      temperature: 0.7,
      messages: [
        { role: "system", content: "You are VerdePath's AI Eco-Advisor. You help logistics fleet managers reduce their carbon footprint through smart routing decisions. Be concise, specific, and data-driven. Always mention exact CO₂ numbers when available. Respond in 2-4 sentences max unless asked for more." },
        { role: "user", content: userMessage }
      ]
    };

    const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${groqKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      const errText = await response.text();
      console.error("Groq API error:", errText);
      throw new Error("Groq API error: " + response.status);
    }

    const data = await response.json();
    const message = data.choices && data.choices[0] ? data.choices[0].message.content : "No response from AI.";

    return new Response(JSON.stringify({ message }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 200,
    });

  } catch (err: any) {
    return new Response(JSON.stringify({ error: err.message }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 400,
    });
  }
});
